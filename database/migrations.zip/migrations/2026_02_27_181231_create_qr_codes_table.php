<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Cek dulu apakah tabel sudah ada
        if (!Schema::hasTable('qr_codes')) {
            Schema::create('qr_codes', function (Blueprint $table) {
                $table->id();
                $table->string('code')->unique();
                $table->enum('status', ['active', 'inactive'])->default('active');
                $table->timestamp('expired_at')->nullable();
                $table->timestamps();
            });
        } else {
            // Jika tabel sudah ada, cek dan tambahkan kolom yang mungkin kurang
            Schema::table('qr_codes', function (Blueprint $table) {
                if (!Schema::hasColumn('qr_codes', 'code')) {
                    $table->string('code')->unique();
                }
                if (!Schema::hasColumn('qr_codes', 'status')) {
                    $table->enum('status', ['active', 'inactive'])->default('active');
                }
                if (!Schema::hasColumn('qr_codes', 'expired_at')) {
                    $table->timestamp('expired_at')->nullable();
                }
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('qr_codes');
    }
};